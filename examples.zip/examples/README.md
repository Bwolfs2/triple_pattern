# Triple - Segmented State Pattern (EXAMPLES)

## Flutter Examples

- [square_counter](./square_counter/)
- [search](./search/)
