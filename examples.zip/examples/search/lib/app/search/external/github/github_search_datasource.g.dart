// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'github_search_datasource.dart';

// **************************************************************************
// InjectionGenerator
// **************************************************************************

final $GithubSearchDatasource = BindInject(
  (i) => GithubSearchDatasource(i<Client>()),
  isSingleton: false,
  isLazy: true,
);
