// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'search_repository_impl.dart';

// **************************************************************************
// InjectionGenerator
// **************************************************************************

final $SearchRepositoryImpl = BindInject(
  (i) => SearchRepositoryImpl(i<SearchDatasource>()),
  isSingleton: false,
  isLazy: true,
);
