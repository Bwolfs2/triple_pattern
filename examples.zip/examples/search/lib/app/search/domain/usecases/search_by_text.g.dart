// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'search_by_text.dart';

// **************************************************************************
// InjectionGenerator
// **************************************************************************

final $SearchByTextImpl = BindInject(
  (i) => SearchByTextImpl(i<SearchRepository>()),
  isSingleton: false,
  isLazy: true,
);
