// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'search_store.dart';

// **************************************************************************
// InjectionGenerator
// **************************************************************************

final $SearchStore = BindInject(
  (i) => SearchStore(i<SearchByText>()),
  isSingleton: true,
  isLazy: true,
);
