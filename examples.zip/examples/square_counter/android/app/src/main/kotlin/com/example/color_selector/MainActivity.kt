package com.example.color_selector

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
